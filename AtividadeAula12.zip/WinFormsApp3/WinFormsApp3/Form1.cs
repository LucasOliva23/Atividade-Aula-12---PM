using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        Database db = new Database();
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LoadData()
        {
            db.OpenConnection();
            string query = "SELECT * FROM Produto";
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, db.GetConnection());
            DataTable table = new DataTable();
            adapter.Fill(table);
            DGV1.DataSource = table;
            db.CloseConnection();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            FormCadastroAtualiza��o formCadastro = new FormCadastroAtualiza��o();
            if (formCadastro.ShowDialog() == DialogResult.OK)
            {
                LoadData(); // Recarrega os dados ap�s adicionar
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (DGV1.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(DGV1.SelectedRows[0].Cells["Id"].Value);
                string nome = DGV1.SelectedRows[0].Cells["Nome"].Value.ToString();
                decimal preco = Convert.ToDecimal(DGV1.SelectedRows[0].Cells["Preco"].Value);

                FormCadastroAtualiza��o formCadastroAtualiza��o = new FormCadastroAtualiza��o(id, nome, preco);
                if (formCadastroAtualiza��o.ShowDialog() == DialogResult.OK)
                {
                    LoadData(); // Recarrega os dados ap�s atualizar
                }
            }
            else
            {
                MessageBox.Show("Selecione um produto para editar.");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (DGV1.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(DGV1.SelectedRows[0].Cells["Id"].Value);
                db.OpenConnection();
                string query = "DELETE FROM Produto WHERE Id = @id";
                MySqlCommand cmd = new MySqlCommand(query, db.GetConnection());
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                db.CloseConnection();
                LoadData(); // Recarrega os dados ap�s excluir
            }
            else
            {
                MessageBox.Show("Selecione um produto para excluir.");
            }
        }
    }
    }
